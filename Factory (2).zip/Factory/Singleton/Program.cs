﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    class Program
    {
        static void Main(string[] args)
        {
            //access level protection - private
            //SingletonLogger logger = new SingletonLogger();

            SingletonLogger obj = SingletonLogger.Instance;
            SingletonLogger obj1 = SingletonLogger.Instance;
            SingletonLogger obj2 = SingletonLogger.Instance;
            Console.Read();
        }

       
    }
    //singleton - non-thread safe
    //selaed to block its inheritance
    public sealed class SingletonLogger
    {
        private static SingletonLogger instance = null;
        //private constructor so that it's instance can not be generated
        private SingletonLogger()
        {
        }
        //Static method or static property
        public static SingletonLogger Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new SingletonLogger();
                    Console.WriteLine("New instance is created");
                }
                Console.WriteLine("same instance returned, no new instance");
                return instance;
            }
        }
    }
    //singleton - thread safe
    public sealed class SingletonThreadSafeLogger
    {
        private static SingletonThreadSafeLogger instance = null;
        private static readonly object padlock = new object();

        SingletonThreadSafeLogger()
        {
        }

        public static SingletonThreadSafeLogger Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new SingletonThreadSafeLogger();
                    }
                    return instance;
                }
            }
        }
    }
    //singleton double check
    public sealed class Singleton
    {
        private static Singleton instance = null;
        private static readonly object padlock = new object();

        Singleton()
        {
        }

        public static Singleton Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (padlock)
                    {
                        if (instance == null)
                        {
                            instance = new Singleton();
                        }
                    }
                }
                return instance;
            }
        }
    }
    //Singleton without locks - thread safe
    public sealed class SingletonNoLocks
    {
        //static initialization
        private static readonly SingletonNoLocks instance = new SingletonNoLocks();

        // Explicit static constructor to tell C# compiler
        // not to mark type as beforefieldinit
        static SingletonNoLocks()
        {
        }

        private SingletonNoLocks()
        {
        }

        public static SingletonNoLocks Instance
        {
            get
            {
                return instance;
            }
        }
    }


}
