﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactorySolution
{
    class Program
    {

        static void Main(string[] args)
        {

            FoodFactory objFoodFactory = new FoodFactory();
            Ieatables objEatables = objFoodFactory.getEatable(Console.ReadLine());
            objEatables.Order();
            objEatables.Deliver();
            Console.ReadLine();

        }
    }

    public interface Ieatables
    {
         void Order();
         void Deliver();

    }
    public class FoodFactory
    {
        public Ieatables getEatable(string choice)
        {
            Ieatables objEatables;
            switch (choice)
            {
                case "Burger":
                    objEatables = new Burger();
                    return objEatables;
                    break;
                case "Pizza":
                    objEatables = new pizza();
                    return objEatables;
                    break;
                default:
                    objEatables = new pizza();
                    return objEatables;
            }
        }
    }

    public class pizza : Ieatables
    {
        public void Order()
        {
            Console.WriteLine("Pizza order received.");
        }
        public void Deliver()
        {
            Console.WriteLine("Pizza order delivered.");
        }

    }
    public class Burger : Ieatables
    {
        public void Order()
        {
            Console.WriteLine("Burger order received.");
        }
        public void Deliver()
        {
            Console.WriteLine("Burger order delivered.");
        }

    }
}
    

