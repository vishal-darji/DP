﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory
{
    class Program
    {
        static void Main(string[] args)
        {

            switch (Console.ReadLine())
            { 
                case "Burger":
                    Burger burger = new Burger();
                    burger.Order();
                    burger.Deliver();
                    break;
                case "Pizza":
                    pizza pizza = new pizza();
                    pizza.Order();
                    pizza.Deliver();
                    break;
            }
            Console.ReadLine();

        }


        public class pizza
        {
            public void Order()
            {
                Console.WriteLine("Pizza order received.");
            }
            public void Deliver()
            {
                Console.WriteLine("Pizza order delivered.");
            }
            
        }
        public class Burger
        {
            public void Order()
            {
                Console.WriteLine("Burger order received.");
            }
            public void Deliver()
            {
                Console.WriteLine("Burger order delivered.");
            }

        }
    }
}
